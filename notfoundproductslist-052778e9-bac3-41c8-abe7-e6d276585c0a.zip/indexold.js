const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const { parse } = require('csv-parse/sync');
const { stringify } = require('csv-stringify/sync');

exports.handler = async (event) => {
    try {
        let method = event.httpMethod;
        let folderName;

        if (method === 'GET') {
            // Existing GET handling
            // Parse folderName from query parameters or body
            if (event.queryStringParameters && event.queryStringParameters.folderName) {
                folderName = event.queryStringParameters.folderName;
            } else if (event.body) {
                const body = JSON.parse(event.body);
                folderName = body.folderName;
            } else {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Folder name is required.' }),
                };
            }

            if (!folderName) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Folder name is required.' }),
                };
            }

            const bucketName = 'redproductslinkingexcel';
            const prefix = `${folderName}/`; // Ensure the prefix ends with '/'

            // List objects in the specified folder
            const listParams = {
                Bucket: bucketName,
                Prefix: prefix,
            };

            const listedObjects = await s3.listObjectsV2(listParams).promise();

            // Filter for CSV files
            const csvFiles = listedObjects.Contents.filter((item) => item.Key.endsWith('.csv'));

            if (csvFiles.length === 0) {
                return {
                    statusCode: 404,
                    body: JSON.stringify({ message: 'No CSV file found in the specified folder.' }),
                };
            }

            if (csvFiles.length > 1) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Multiple CSV files found. Expected only one.' }),
                };
            }

            const csvFileKey = csvFiles[0].Key;

            // Get the CSV file content
            const getObjectParams = {
                Bucket: bucketName,
                Key: csvFileKey,
            };

            const csvData = await s3.getObject(getObjectParams).promise();
            const csvContent = csvData.Body.toString('utf-8');

            // Parse the CSV content
            const records = parse(csvContent, {
                columns: true, // Use the first row as header
                skip_empty_lines: true,
            });

            // Extract headers
            const headers = records.length > 0 ? Object.keys(records[0]) : [];

            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    // CORS headers if needed
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({
                    headers: headers,
                    data: records,
                }),
            };
        } else if (method === 'POST') {
            // Handle POST request
            if (!event.body) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Request body is required.' }),
                };
            }

            const body = JSON.parse(event.body);
            const { row, barcode, image, folderName } = body;

            // Validate required fields
            if (!folderName) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Folder name is required.' }),
                };
            }

            if (!row || !barcode || !image) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Row, barcode, and image are required.' }),
                };
            }

            const rowNumber = parseInt(row, 10);
            if (isNaN(rowNumber) || rowNumber < 1) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Row must be a positive integer.' }),
                };
            }

            // **NEW: Strip Data URI Prefix if Present**
            const base64Data = stripDataUri(image);

            const bucketName = 'redproductslinkingexcel';
            const prefix = `${folderName}/`; // Ensure the prefix ends with '/'

            // Locate the CSV file as before...
            const listParams = {
                Bucket: bucketName,
                Prefix: prefix,
            };

            const listedObjects = await s3.listObjectsV2(listParams).promise();

            // Filter for CSV files
            const csvFiles = listedObjects.Contents.filter((item) => item.Key.endsWith('.csv'));

            if (csvFiles.length === 0) {
                return {
                    statusCode: 404,
                    body: JSON.stringify({ message: 'No CSV file found in the specified folder.' }),
                };
            }

            if (csvFiles.length > 1) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Multiple CSV files found. Expected only one.' }),
                };
            }

            const csvFileKey = csvFiles[0].Key;

            // Get the CSV file content
            const getObjectParams = {
                Bucket: bucketName,
                Key: csvFileKey,
            };

            const csvData = await s3.getObject(getObjectParams).promise();
            const csvContent = csvData.Body.toString('utf-8');

            // Parse the CSV content
            const records = parse(csvContent, {
                columns: true, // Use the first row as header
                skip_empty_lines: true,
            });

            // Check if 'barcode' and 'images' columns exist, if not, add them
            let headers = records.length > 0 ? Object.keys(records[0]) : [];

            let needToAddBarcode = !headers.includes('barcode');
            let needToAddImages = !headers.includes('images');

            if (needToAddBarcode) {
                headers.push('barcode');
            }
            if (needToAddImages) {
                headers.push('images');
            }

            // Ensure all records have 'barcode' and 'images' fields
            records.forEach(record => {
                if (needToAddBarcode) {
                    record['barcode'] = '';
                }
                if (needToAddImages) {
                    record['images'] = '';
                }
            });

            // Check if rowNumber exists
            if (rowNumber > records.length) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: `Row number ${rowNumber} does not exist in the CSV file.` }),
                };
            }

            // Get the record to update (rows are 1-based)
            const recordToUpdate = records[rowNumber - 1];

            // Upload the image to S3
            // Generate a unique image name, e.g., using timestamp and a random string
            const imageBuffer = Buffer.from(base64Data, 'base64');
            const imageExtension = getImageExtension(imageBuffer); // Function to determine image extension
            const imageName = `image_${Date.now()}_${Math.random().toString(36).substring(2, 15)}.${imageExtension}`;
            const imageKey = `${folderName}/images/${imageName}`;

            // Upload the image
            const uploadParams = {
                Bucket: bucketName,
                Key: imageKey,
                Body: imageBuffer,
                ContentEncoding: 'base64',
                ContentType: `image/${imageExtension}`, // e.g., 'image/png' or 'image/jpeg'
            };

            await s3.putObject(uploadParams).promise();

            // Generate the image URL
            // Assuming the bucket is public or you have a method to generate presigned URLs
            // For simplicity, constructing the URL
            const imageUrl = `https://${bucketName}.s3.amazonaws.com/${imageKey}`;

            // Update the record
            recordToUpdate['barcode'] = barcode;
            recordToUpdate['images'] = imageUrl;

            // Convert the records back to CSV
            const newCsvContent = stringify(records, {
                header: true,
                columns: headers,
            });

            // Upload the modified CSV back to S3 (overwrite the original)
            const putObjectParams = {
                Bucket: bucketName,
                Key: csvFileKey,
                Body: newCsvContent,
                ContentType: 'text/csv',
            };

            await s3.putObject(putObjectParams).promise();

            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*', // Adjust as needed
                    'Access-Control-Allow-Headers': '*', // Adjust as needed
                },
                body: JSON.stringify({ message: 'Row updated successfully.', imageUrl: imageUrl }),
            };
        } else {
            // Method not supported
            return {
                statusCode: 405,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: 'Method not allowed.' }),
            };
        }
    } catch (error) {
        console.error('Error processing request:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal Server Error', error: error.message }),
        };
    }
};

// Helper function to determine image extension based on buffer
function getImageExtension(buffer) {
    // Simple check based on magic numbers
    if (buffer.slice(0, 4).toString('hex') === '89504e47') {
        return 'png';
    } else if (buffer.slice(0, 3).toString('hex') === 'ffd8ff') {
        return 'jpeg';
    } else {
        // Default to png if unknown
        return 'png';
    }
}

// Helper function to strip Data URI prefix if present
function stripDataUri(dataUri) {
    const regex = /^data:image\/\w+;base64,/;
    return dataUri.replace(regex, '');
}
