const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const { parse } = require('csv-parse/sync');
const { stringify } = require('csv-stringify/sync');
const FileType = require('file-type');

// Configuration: Set the expiration time for pre-signed URLs (in seconds)
const PRESIGNED_URL_EXPIRATION = 60 * 60; // 1 hour
const bucketName = 'notfoundproductslist';

exports.handler = async (event) => {
    try {
        const method = event.httpMethod;

        // CORS Preflight (OPTIONS) handler
        if (method === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
                },
                body: JSON.stringify({ message: 'CORS preflight success.' }),
            };
        }

        if (method === 'GET') {
            return await handleGetRequest(event);
        } else if (method === 'POST') {
            return await handlePostRequest(event);
        } else {
            // Method not supported
            return {
                statusCode: 405,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: 'Method not allowed.' }),
            };
        }
    } catch (error) {
        console.error('Error processing request:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'Internal Server Error', error: error.message }),
        };
    }
};

async function handleGetRequest(event) {
    let folderName;
    // Parse folderName from query parameters or body
    if (event.queryStringParameters && event.queryStringParameters.folderName) {
        folderName = event.queryStringParameters.folderName;
    } else if (event.body) {
        const body = JSON.parse(event.body);
        folderName = body.folderName;
    }

    if (!folderName) {
        return {
            statusCode: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'Folder name is required.' }),
        };
    }

    const prefix = `${folderName}/`; // Ensure the prefix ends with '/'
    const listParams = {
        Bucket: bucketName,
        Prefix: prefix,
    };

    const listedObjects = await s3.listObjectsV2(listParams).promise();

    // Filter for CSV files
    const csvFiles = (listedObjects.Contents || []).filter((item) => item.Key.endsWith('.csv'));

    if (csvFiles.length === 0) {
        return {
            statusCode: 404,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'No CSV file found in the specified folder.' }),
        };
    }

    if (csvFiles.length > 1) {
        return {
            statusCode: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'Multiple CSV files found. Expected only one.' }),
        };
    }

    const csvFileKey = csvFiles[0].Key;
    const getObjectParams = {
        Bucket: bucketName,
        Key: csvFileKey,
    };

    const csvData = await s3.getObject(getObjectParams).promise();
    const csvContent = csvData.Body.toString('utf-8');

    const records = parse(csvContent, {
        columns: true, // Use the first row as header
        skip_empty_lines: true,
    });

    // Extract headers
    const headers = records.length > 0 ? Object.keys(records[0]) : [];

    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': '*',
        },
        body: JSON.stringify({
            headers: headers,
            data: records,
        }),
    };
}

async function handlePostRequest(event) {
    if (!event.body) {
        return {
            statusCode: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'Request body is required.' }),
        };
    }

    const body = JSON.parse(event.body);
    const { row, barcode, frontImage, backImage, folderName } = body;

    // Validate required fields
    if (!folderName) {
        return {
            statusCode: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'Folder name is required.' }),
        };
    }

    if (!row) {
        return {
            statusCode: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'Row is required.' }),
        };
    }

    const rowNumber = parseInt(row, 10);
    if (isNaN(rowNumber) || rowNumber < 1) {
        return {
            statusCode: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'Row must be a positive integer.' }),
        };
    }

    const prefix = `${folderName}/`;
    const listParams = {
        Bucket: bucketName,
        Prefix: prefix,
    };

    const listedObjects = await s3.listObjectsV2(listParams).promise();
    const csvFiles = (listedObjects.Contents || []).filter((item) => item.Key.endsWith('.csv'));

    if (csvFiles.length === 0) {
        return {
            statusCode: 404,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'No CSV file found in the specified folder.' }),
        };
    }

    if (csvFiles.length > 1) {
        return {
            statusCode: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: 'Multiple CSV files found. Expected only one.' }),
        };
    }

    const csvFileKey = csvFiles[0].Key;
    const getObjectParams = {
        Bucket: bucketName,
        Key: csvFileKey,
    };

    const csvData = await s3.getObject(getObjectParams).promise();
    const csvContent = csvData.Body.toString('utf-8');

    const records = parse(csvContent, {
        columns: true,
        skip_empty_lines: true,
    });

    let headers = records.length > 0 ? Object.keys(records[0]) : [];

    // Ensure barcode, frontImage, backImage columns exist
    let needToAddBarcode = !headers.includes('barcode');
    let needToAddFront = !headers.includes('frontImage');
    let needToAddBack = !headers.includes('backImage');

    if (needToAddBarcode) headers.push('barcode');
    if (needToAddFront) headers.push('frontImage');
    if (needToAddBack) headers.push('backImage');

    // Ensure all existing records have these fields
    records.forEach(record => {
        if (needToAddBarcode) record['barcode'] = '';
        if (needToAddFront) record['frontImage'] = '';
        if (needToAddBack) record['backImage'] = '';
    });

    // Check if we need to add a new row
    if (rowNumber > records.length + 1) {
        return {
            statusCode: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
            },
            body: JSON.stringify({ message: `Cannot add row ${rowNumber}. You can only add the next row at ${records.length + 1}.` }),
        };
    }

    let recordToUpdate;
    if (rowNumber === records.length + 1) {
        // Add a new row
        const newRecord = {};
        headers.forEach(header => {
            newRecord[header] = '';
        });
        records.push(newRecord);
        recordToUpdate = newRecord;
    } else {
        // Update existing row
        if (rowNumber > records.length) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                body: JSON.stringify({ message: `Row number ${rowNumber} does not exist in the CSV file.` }),
            };
        }
        recordToUpdate = records[rowNumber - 1];
    }

    // Update the barcode field (if provided)
    if (barcode !== undefined) {
        recordToUpdate['barcode'] = barcode;
    }

    // Function to handle image upload if we have base64 data
    const uploadImageIfProvided = async (base64String, imageType) => {
        if (!base64String) return '';
        
        // Strip Data URI Prefix if Present
        const strippedBase64 = stripDataUri(base64String);

        // Validate base64
        if (!isValidBase64(strippedBase64)) {
            throw new Error(`Invalid base64 image data for ${imageType}.`);
        }

        // Limit image size (e.g., 5MB)
        const MAX_BASE64_SIZE = 5 * 1024 * 1024; // 5MB
        if (strippedBase64.length > (MAX_BASE64_SIZE * 4) / 3) {
            throw new Error(`${imageType} size exceeds the 5MB limit.`);
        }

        const imageBuffer = Buffer.from(strippedBase64, 'base64');
        const imageExtension = await getImageExtension(imageBuffer);
        const imageName = `${imageType}_${Date.now()}_${Math.random().toString(36).substring(2, 15)}.${imageExtension}`;
        const imageKey = `${folderName}/images/${imageName}`;

        const uploadParams = {
            Bucket: bucketName,
            Key: imageKey,
            Body: imageBuffer,
            ContentEncoding: 'base64',
            ContentType: `image/${imageExtension}`,
        };

        await s3.putObject(uploadParams).promise();

        // Generate a pre-signed URL
        const imageUrl = s3.getSignedUrl('getObject', {
            Bucket: bucketName,
            Key: imageKey,
            Expires: PRESIGNED_URL_EXPIRATION,
        });
        return imageUrl;
    };

    // Upload front image if provided
    let frontImageUrl = '';
    if (frontImage) {
        frontImageUrl = await uploadImageIfProvided(frontImage, 'frontImage');
        if (frontImageUrl) recordToUpdate['frontImage'] = frontImageUrl;
    }

    // Upload back image if provided
    let backImageUrl = '';
    if (backImage) {
        backImageUrl = await uploadImageIfProvided(backImage, 'backImage');
        if (backImageUrl) recordToUpdate['backImage'] = backImageUrl;
    }

    // Convert the records back to CSV
    const newCsvContent = stringify(records, {
        header: true,
        columns: headers,
    });

    // Upload the modified CSV back to S3 (overwrite the original)
    const putObjectParams = {
        Bucket: bucketName,
        Key: csvFileKey,
        Body: newCsvContent,
        ContentType: 'text/csv',
    };

    await s3.putObject(putObjectParams).promise();

    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': '*',
        },
        body: JSON.stringify({
            message: 'Row updated successfully.',
            frontImageUrl: frontImageUrl || null,
            backImageUrl: backImageUrl || null
        }),
    };
}

// Helper function to determine image extension based on buffer using file-type
async function getImageExtension(buffer) {
    const type = await FileType.fromBuffer(buffer);
    if (type && ['png', 'jpeg', 'jpg', 'gif', 'bmp', 'webp'].includes(type.ext)) {
        return type.ext === 'jpg' ? 'jpeg' : type.ext; // Normalize 'jpg' to 'jpeg'
    }
    // Default to 'png' if type is unknown
    return 'png';
}

// Helper function to strip Data URI prefix if present
function stripDataUri(dataUri) {
    const regex = /^data:image\/\w+;base64,/;
    return dataUri.replace(regex, '');
}

// Helper function to validate base64 string
function isValidBase64(str) {
    try {
        return Buffer.from(str, 'base64').toString('base64') === str.replace(/\s+/g, '');
    } catch (err) {
        return false;
    }
}
